#include <stdio.h>

main () {
	int n1, n2;
	
	printf ("Digite o primeiro numero inteiro: ");
	scanf ("%d", &n1);
	
	printf ("Digite o segundo numero inteiro: ");
	scanf ("%d", &n2);
	
	if (n1==n2) {
		printf ("Os numeros sao iguais");
	} else {
		printf ("Os numeros sao diferentes");
	}
}
