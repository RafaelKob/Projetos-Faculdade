#include <stdio.h>

main () {
	int nmaca;
	float ct;
	
	printf ("Digite o numero de macas a serem compradas: ");
	scanf ("%d", &nmaca);
	
	if (nmaca < 12) {
		ct = 1.3*nmaca;
		printf ("O custo total a ser pago pelas macas é: %.2f", ct);
	} else {
		ct = 1.0*nmaca;
		printf ("O custo total a ser pago pelas macas é: %.2f", ct);
	}
}