#include <stdio.h>

main () {
	int idade;
	
	printf ("Informe a idade do atleta: "); 
	scanf ("%d", &idade); 
	
	if (idade>=5 && idade<=7) {
		printf ("O atleta esta na categoria INFANTIL A");
	} else if (idade>=8 && idade<=10) {
		printf ("O atleta esta na categoria INFANTIL B");
	} else if (idade>=11 && idade<=13) {
		printf ("O atleta esta na categoria JUVENIL A");
	} else if (idade>=14 && idade<=17) {
		printf ("O atleta esta na categoria JUVENIL B");
	} else if (idade>=18) {
		printf ("O atleta esta na categoria ADULTO");
	} else {
		printf ("O atleta nao encaixa em nenhuma categoria");
	}
}