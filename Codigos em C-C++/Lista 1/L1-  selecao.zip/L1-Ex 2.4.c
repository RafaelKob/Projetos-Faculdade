#include <stdio.h>

main () {
	float n1, n2, media;
	
	printf ("Informe as duas notas de prova do aluno (0 a 10): "); 
	scanf ("%f%f", &n1, &n2); //escrever duas variaveis na mesma linha
	
	media = (n1+n2)/2;
	
	if (media >= 6) {
		printf ("A media do aluno é: %.1f e o aluno foi aprovado", media);
	} else {
		printf ("A media do aluno é: %.1f e o aluno foi reprovado", media);
	}
}
