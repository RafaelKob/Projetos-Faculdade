#include <stdio.h>

main () {
	int tipo;
	float litros, ct;
	
	printf ("Informe o tipo de combustivel a ser usado: \n 1-alcool \n 2-gasolina \n"); 
	scanf ("%d", &tipo); 
	
	printf ("Informe o numero de litros comprados: "); 
	scanf ("%f", &litros); 
	
	
	if (tipo==1) {
		if (litros<=20) {
			ct=2.90*0.97*litros;
		} else {
			ct=2.9*0.95*litros;
		}
		printf ("O valor a ser pago pelo cliente é: %.2f", ct);
	} else if (tipo==2) {
		if (litros<=20) {
			ct=3.30*0.96*litros;
		} else {
			ct=3.30*0.94*litros;
		}
		printf ("O valor a ser pago pelo cliente é: %.2f", ct);
	}
}