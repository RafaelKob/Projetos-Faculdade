#include <stdio.h>

main () {
	int tipo;
	float valorcompra,valorf;
	
	printf ("Informe qual o tipo de cliente:\n 1-cliente comum \n 2-funcionario \n 3-vip \n");
	scanf ("%d", &tipo);
	
	printf ("Digite o valor da compra de uma pessoa: ");
	scanf ("%f", &valorcompra);
	
	if (tipo==1) {
		valorf = valorcompra;
		printf ("O valor da compra com desconto para cliente comum é: %.2f", valorf);
	} else if (tipo==2) {
		valorf = 0.9*valorcompra;
		printf ("O valor da compra com desconto para funcionario é: %.2f", valorf);		
	} else if (tipo==3) {
		valorf = 0.95*valorcompra;
		printf ("O valor da compra com desconto para cliente vip é: %.2f", valorf);
	} else {
		printf ("Foi informado um tipo invalido de cliente");
	}
}