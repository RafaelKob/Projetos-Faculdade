#include <stdio.h>

main () {
	int n1, n2, soma, i;
	
	do {
		printf("Digite os valores de dois numeros: "); //declarar dois na mesma linha
		scanf("%d%d",&n1,&n2);
	} while (n1>n2);
	
	soma=0;
	
	for (i=n1; i<=n2; i++) {
		soma=soma+i;
	}
	
	printf("A soma dos numeros inteiros entre %d e %d é: %d", n1, n2, soma);
}