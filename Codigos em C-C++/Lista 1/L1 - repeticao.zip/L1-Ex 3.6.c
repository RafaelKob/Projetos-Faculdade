#include <stdio.h>

main () {
	int n, fatorial, i;
	
	printf("Digite um numero positivo: ");
	scanf("%d", &n);
	
	fatorial = 1;
	if (n == 0) {
		printf ("O fatorial de 0 é igual a: %d", fatorial);
	} else {
		for (i=1; i<=n; i++) {
			fatorial = fatorial*i;
		}
		printf ("O fatorial do numero %d é: %d", n, fatorial);
	}
}