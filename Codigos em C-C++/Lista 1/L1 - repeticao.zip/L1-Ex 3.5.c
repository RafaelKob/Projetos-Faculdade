#include <stdio.h>

main () {
	int i=0;
	float altChico=1.50, altJuca=1.10;

	do {
		altChico=altChico + 0.02;
		altJuca=altJuca + 0.03;
		i=i+1;
	} while (altChico > altJuca);
	
	printf("Serao necessarios %d anos para o juca tornar-se mais alto que chico", i);
}
