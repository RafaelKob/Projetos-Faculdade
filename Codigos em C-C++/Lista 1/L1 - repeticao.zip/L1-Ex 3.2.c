#include <stdio.h>

main () {
	int n, resto;
	
	printf ("Os numeros pares no intervalo de 1 a 38 é: ");
	for (n=1; n<39; n++) {
		resto = n%2;
		if (resto==0) {
			printf ("\n %d", n);
		}
	}
}