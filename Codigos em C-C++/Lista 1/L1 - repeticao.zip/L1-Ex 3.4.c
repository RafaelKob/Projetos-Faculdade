#include <stdio.h>

main () {
	int cod, i;
	float preco, maior=0,soma=0, ma; //inicia maior igual a zero pois não existira preço negativo

	for (i=0; i<15; i++) {
		printf("Digite o codigo do produto: ");
		scanf("%d",&cod);
		printf("Digite o respectivo preço do produto: ");
		scanf("%f",&preco);
		if (preco>maior) {
			maior=preco;
		}
		soma=soma+preco;
	}
	ma=soma/15;
	
	printf("O maior preço é %f:", maior);
	printf("\nA media aritmetica dos precos dos produtos: %.2f", ma);
}
