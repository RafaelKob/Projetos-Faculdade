#include <stdio.h>

main () {
	int n;
	
	for (n=1; n<51; n++) {
		printf ("\n%d", n);
	}
}