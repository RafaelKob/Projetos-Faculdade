#include <stdio.h>

main () {
	float custoFab, custoF;
	
	printf ("Digite o valor do custo de fabrica do carro em reais: ");
	scanf ("%f", &custoFab);
	
	custoF = custoFab + 0.28*custoFab + 0.45*custoFab;
	
	printf ("\nO valor final do carro novo é: %.2f", custoF);
}