#include <stdio.h>

main () {
	float pol, cm;
	
	printf ("Digite uma medida em polegada: ");
	scanf ("%f", &pol);
	
	cm = 2.54*pol;
	
	printf ("\nO valor da medida escolhida em cm é: %.2f", cm);
}
