#include <stdio.h>

main () {
	int n, ant, suc;
	
	printf ("Digite um número inteiro: ");
	scanf ("%d", &n);
	
	ant = n - 1;
	suc = n + 1;
	
	printf ("\nO valor do antecessor do número escolhido é: %d", ant);
	printf ("\nO valor do sucessor do número é: %d", suc);
}